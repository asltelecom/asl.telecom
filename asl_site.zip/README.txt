
Projeto: ASL Telecom — site multi-page
Arquivos incluídos na pasta: /mnt/data/asl_website

Substitua img/logo.png pelo seu logo (já incluí o arquivo que você enviou).
Para testar localmente: abra index.html no navegador.
Para tornar o formulário funcional, troque a action do contato para Formspree ou seu endpoint de servidor.
WhatsApp usado nos botões: https://wa.me/5544984539929
Telefone fixo mostrado: (44) 3233-0287

Se quiser, eu posso agora:
- gerar o ZIP (já criado abaixo) e deixar pronto para download,
- ou publicar no GitHub Pages / Netlify (te guio passo a passo).
